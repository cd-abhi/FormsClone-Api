export default {
    secret: 'secret',
  };
  