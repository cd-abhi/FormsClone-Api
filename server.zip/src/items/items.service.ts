import { Injectable, NotFoundException } from '@nestjs/common';
import { ItemsEntity } from './entity/items.entity';
import { ItemsInputType } from './types/items.input.type';
import { FormEntity } from 'src/forms/entity/forms.entity';
import { ID } from '@nestjs/graphql';

@Injectable()
export class ItemsService {
  async items(id: number) {
    return await ItemsEntity.findBy({ formId: id });
  }

  async createItem(form: FormEntity, input: ItemsInputType) {
    const { question, description } = input;
    const item = new ItemsEntity();
    item.question = question;
    item.description = description;
    item.form = form;
    await item.save();
    return item;
  }

  async deleteItem(id: number) {
    const item = await ItemsEntity.findOneBy({ id });
    if (!item) throw new NotFoundException('Item not Found');
    await item.remove();
    var result = `Item with id ${id} deleted`;
    return { result };
  }
}
